#!/bin/bash
echo "Starting MediCheck Pharmacist Review..."
if command -v python3 &>/dev/null; then
    python3 web.py
elif command -v python &>/dev/null; then
    python web.py
else
    echo "ERROR: Python not found. Please install Python 3.8+ from https://python.org"
    read -p "Press Enter to exit..."
fi
