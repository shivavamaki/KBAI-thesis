MediCheck — Pharmacist Review App
===================================

REQUIREMENTS
  - Python 3.8 or newer (free from https://python.org)
  - No other packages needed

HOW TO RUN
  Windows  : double-click  start_windows.bat
  Mac/Linux: run           ./start_mac_linux.sh
  Any OS   : open a terminal here, then run   python web.py

  The app opens automatically in your browser at http://localhost:8501
  Press Ctrl+C in the terminal to stop the server.

CUSTOM PORT
  python web.py --port 9000

LOAD A FILE
  1. Click "Browse..." and select your JSON file
     (or type the full path to the file)
  2. Set the output path where results will be saved
  3. Click "Load File"

JSON FORMAT
  The input file must be an array of prescription records, e.g.:
  [
    { "ID": "O0001234567", "SUMMARY": "...", "DETAIL": "...", "ROWTYPE": "Daily" },
    ...
  ]

OUTPUT
  Results are auto-saved to the output path every time you click Save.
  Use the "Export JSON" button in the top bar to download a copy.
