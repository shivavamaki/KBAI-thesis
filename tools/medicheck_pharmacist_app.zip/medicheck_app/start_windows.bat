@echo off
echo Starting MediCheck Pharmacist Review...
python web.py
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ERROR: Python not found. Please install Python 3.8+ from https://python.org
    pause
)
